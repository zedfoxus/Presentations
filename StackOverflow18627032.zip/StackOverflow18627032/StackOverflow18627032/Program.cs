﻿using System;
using System.Data.OleDb;

namespace StackOverflow18627032
{
    // http://stackoverflow.com/questions/18627032/update-excel-2010-but-no-row-changes
    class Program
    {
        static void Main()
        {
            // uncomment the following to update the named range
            const string table = "usefulinformation";

            // uncomment the following to update Sheet2. Ensure that only
            // one const string table is uncommented
            //const string table = "Sheet2$";

            using (var myConnection = new OleDbConnection(GetExcelConnectionStringByWrite()))
            using (var myCommand = new OleDbCommand())
            {
                myConnection.Open();

                myCommand.Connection = myConnection;
                myCommand.CommandText =
                    string.Format("UPDATE [{0}] SET Status ='Imported' WHERE Status IN ( SELECT TOP 5 Status FROM [{0}] )", table);
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }

            Console.WriteLine("Done");
            Console.ReadKey();
        }

        private static string GetExcelConnectionStringByWrite()
        {
            return
                @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Test.xlsx;Extended Properties='Excel 12.0;HDR=YES;IMEX=0;MAXSCANROWS=10;READONLY=FALSE'";
        }
    }
}
